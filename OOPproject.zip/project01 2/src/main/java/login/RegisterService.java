/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package login;


import com.mongodb.client.MongoCollection;
import org.bson.Document;

/**
 *
 * @author melisandre
 */
public class RegisterService {
    private MongoCollection<Document> usersCollection;

    public RegisterService(MongoCollection<Document> usersCollection) {
        this.usersCollection = usersCollection;
    }

    public void registerUser(User user) {
        usersCollection.insertOne(user.toDocument());
    }
}