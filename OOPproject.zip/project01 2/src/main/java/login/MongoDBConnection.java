/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package login;



import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class MongoDBConnection {
    private MongoClient mongoClient;
    private MongoDatabase database;

    public MongoDBConnection() {
        String uri = "mongodb+srv://momo:momo@cluster0.6kamogv.mongodb.net/";
        mongoClient = MongoClients.create(uri);
        database = mongoClient.getDatabase("OOPproject");
    }

    public MongoCollection<Document> getUsersCollection() {
        return database.getCollection("account");
    }
}

