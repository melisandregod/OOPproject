/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package login;


import org.bson.Document;

public class User {
    private String username;
    private String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Document toDocument() {
        return new Document("username", username)
            .append("password", password);
    }

    public static User fromDocument(Document document) {
        String username = document.getString("username");
        String password = document.getString("password");
        return new User(username, password);
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
         return password;
    }
}









