/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package login;


import com.mongodb.client.MongoCollection;
import org.bson.Document;

/**
 *
 * @author melisandre
 */
public class LoginService {
    private MongoCollection<Document> usersCollection;

    public LoginService(MongoCollection<Document> usersCollection) {
        this.usersCollection = usersCollection;
    }

    public boolean loginUser(User user) {
        Document query = new Document("username", user.getUsername()).append("password", user.getPassword());

        return usersCollection.find(query).first() != null;
    }
}